function navigateToLogin() {
    // You can replace the following URL with the actual login page URL
    window.location.href = 'login.html';
}

function navigateToSignup() {
    // You can replace the following URL with the actual signup page URL
    window.location.href = 'signup.html';
}
